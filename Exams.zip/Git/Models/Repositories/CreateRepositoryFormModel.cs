﻿namespace Git.Models.Repositories
{
    public class CreateRepositoryFormModel
    {
        public string Name { get; init; }

        public string RepositoryType { get; init; }
    }
}
